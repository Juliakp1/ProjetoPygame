# ProjetoPygame

Jogo similar ao flappy bird, com power-ups, customização e um modo de jogo secreto

Mecânicas:

- Pular (entre os canos)
- Portais (leva ao ping-pong bird para mais pontos)
- Customização de todos os sprites
-
- Melancia (power-ups que dao invicibilidade)
- Lichia (power-ups que te deixam menor)
- Cafe (power-ups que deixam rapido)
- Jaca (power-ups que deixam devagar)
- Carambola (power-ups que aumenta o tamanho das moedas)
